select * from cleaned_returns;

CREATE INDEX idx_cleaned_returns
ON cleaned_returns(
  return_id(100),
  order_id(100),
  return_date(100),
  return_reason(10)
  );
  SHOW INDEX FROM cleaned_returns;
  
  
  
  select * from cleaned_stores;
  CREATE INDEX idx_cleaned_stores
ON cleaned_stores (
  store_id(100),
  store_name(100),
  store_type(100),
  region(10),
  city(100),
  operating_cost
);
SHOW INDEX FROM cleaned_stores;
  
 