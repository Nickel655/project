DROP INDEX idx_customer_profile ON cleaned_customers;
CREATE INDEX idx_customer_profile
ON cleaned_customers (
  customer_id(100),
  first_name(100),
  last_name(100),
  gender(10),
  age,
  signup_date,
  region(100)
);
ALTER TABLE cleaned_customers
MODIFY signup_date DATE;

SHOW INDEX FROM cleaned_customers;


select * from cleaned_customers

