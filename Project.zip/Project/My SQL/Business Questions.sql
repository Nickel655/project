

-- Business Question 
-- 1.What is the total revenue generated in the last 12 months?   
SELECT monthname(order_date),SUM(total_amount) AS total_revenue
FROM cleaned_sales
WHERE order_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH) group by monthname(order_date) order by total_revenue desc;


-- 2.Which are the top 5 best-selling products by quantity? 
SELECT p.product_name, SUM(s.quantity) AS total_sold
FROM cleaned_sales s
JOIN cleaned_products p ON s.product_id = p.product_id
GROUP BY p.product_name
ORDER BY total_sold DESC
LIMIT 5;



 -- 3.How many customers are from each region? 
SELECT region, COUNT(customer_id) AS customer_count
FROM cleaned_customers
GROUP BY region
ORDER BY customer_count DESC;


-- 4.Which store has the highest profit in the past year? 
SELECT store_name, 
       SUM(total_amount - operating_cost) AS total_profit
FROM cleaned_sales s
JOIN cleaned_stores st ON s.store_id = st.store_id
WHERE order_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
GROUP BY store_name
ORDER BY total_profit DESC
LIMIT 1;



-- 5.What is the return rate by product category?
SELECT p.category, 
       COUNT(r.return_id) * 100.0 / COUNT(s.order_id) AS return_rate
FROM cleaned_sales s
LEFT JOIN cleaned_returns r ON s.order_id = r.order_id
LEFT JOIN cleaned_products p ON s.product_id = p.product_id
GROUP BY p.category
ORDER BY return_rate DESC;



 -- 6.What is the average revenue per customer by age group? 
SELECT 
    CASE 
        WHEN c.age BETWEEN 18 AND 25 THEN '18-25'
        WHEN c.age BETWEEN 26 AND 35 THEN '26-35'
        WHEN c.age BETWEEN 36 AND 50 THEN '36-50'
        ELSE '50+' 
    END AS age_group,
    AVG(s.total_amount) AS avg_revenue_per_customer
FROM cleaned_sales s
JOIN cleaned_customers c ON s.customer_id = c.customer_id
GROUP BY age_group
ORDER BY avg_revenue_per_customer DESC;



-- 7. Which sales channel (Online vs In-Store) is more profitable on average? 
SELECT s.sales_channel, 
       SUM(s.total_amount - st.operating_cost) / COUNT(DISTINCT st.store_id) AS avg_profit_per_store
FROM cleaned_sales s
LEFT JOIN cleaned_stores st ON s.store_id = st.store_id
GROUP BY s.sales_channel
ORDER BY avg_profit_per_store DESC;

--           OR

 SELECT s.sales_channel, 
       SUM(s.total_amount) AS total_revenue,
       SUM(s.total_amount - COALESCE(st.operating_cost, 0)) AS total_profit
FROM cleaned_sales s
LEFT JOIN cleaned_stores st ON s.store_id = st.store_id
GROUP BY s.sales_channel
ORDER BY total_profit DESC;



-- 8. How has monthly profit changed over the last 2 years by region?
SELECT DATE_FORMAT(s.order_date, '%Y-%m') AS month, 
       st.region, 
       SUM(s.total_amount - st.operating_cost) AS total_profit
FROM cleaned_sales s
JOIN cleaned_stores st ON s.store_id = st.store_id
WHERE s.order_date >= DATE_SUB(CURDATE(), INTERVAL 24 MONTH)
GROUP BY month, st.region
ORDER BY month DESC, total_profit DESC;



-- 9.Identify the top 3 products with the highest return rate in each category. 
SELECT p.category, p.product_name, 
       COUNT(r.return_id) * 100.0 / COUNT(s.order_id) AS return_rate
FROM cleaned_sales s
LEFT JOIN cleaned_returns r ON s.order_id = r.order_id
LEFT JOIN cleaned_products p ON s.product_id = p.product_id
GROUP BY p.category, p.product_name
ORDER BY p.category, return_rate DESC
LIMIT 3;



-- 10.Which 5 customers have contributed the most to total profit, and what is their tenure with the company? 
SELECT c.customer_id, 
       CONCAT(c.first_name, ' ', c.last_name) AS customer_name, 
       SUM(s.total_amount - p.cost_price * s.quantity) AS total_profit,
       DATEDIFF(CURDATE(), c.signup_date) / 365 AS tenure_years
FROM cleaned_sales s
JOIN cleaned_customers c ON s.customer_id = c.customer_id
JOIN cleaned_products p ON s.product_id = p.product_id
GROUP BY c.customer_id, customer_name, tenure_years
ORDER BY total_profit DESC
LIMIT 5;




















