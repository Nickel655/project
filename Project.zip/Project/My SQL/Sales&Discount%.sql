select * from cleaned_sales;
SELECT order_id, 
       (total_amount - (cost_price * quantity)) AS profit
FROM cleaned_sales
JOIN cleaned_products ON cleaned_sales.product_id = cleaned_products.product_id;


SELECT order_id, 
       unit_price, 
       discount_pct, 
       (unit_price * (1 - discount_pct)) AS discounted_pct
FROM cleaned_sales;





